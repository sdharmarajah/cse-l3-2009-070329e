/*
/*

Author Information

@author Isuru Udana Loku Narangoda
Department of Computer Science & Engineering,
University of Moratuwa,
Sri Lanka.

Blog: http://mytecheye.blogspot.com/
Facebook : http://www.facebook.com/isudana
GoogleTalk : isudana
Skype: isudana
Twitter: http://twitter.com/isudana
*/

// isadmin.cpp : Defines the entry point for the DLL application.
//
#include "windows.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
    return TRUE;
}
