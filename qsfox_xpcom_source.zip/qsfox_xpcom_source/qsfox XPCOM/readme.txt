Sometimes qsfox.h get disappeared. 
Still cannot find a reason. 
copy qsfox.h from backup dir to project root folder if the buid is failed.