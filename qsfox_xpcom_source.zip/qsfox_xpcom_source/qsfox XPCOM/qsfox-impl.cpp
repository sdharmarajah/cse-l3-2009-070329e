/*
/*

Author Information

@author Isuru Udana Loku Narangoda
Department of Computer Science & Engineering,
University of Moratuwa,
Sri Lanka.

Blog: http://mytecheye.blogspot.com/
Facebook : http://www.facebook.com/isudana
GoogleTalk : isudana
Skype: isudana
Twitter: http://twitter.com/isudana
*/





#include "qsfox-impl.h"
#include "isuseradmin.h"
#include "windows.h"

NS_IMPL_ISUPPORTS1(Cqsfox, Iqsfox)

Cqsfox::Cqsfox()
{
	/* member initializers and constructor code */
}

Cqsfox::~Cqsfox()
{
	/* destructor code */
}

NS_IMETHODIMP Cqsfox::Isadmin(PRBool *_retval)
{
	if (IsUserAdmin()) {
	//if (true) {
		*_retval = PR_TRUE;
	} else {
		*_retval = PR_FALSE;
	}
	return NS_OK;
}

NS_IMETHODIMP Cqsfox::Addfont(const char *path)
{

AddFontResource(path);



SendMessage( 
  HWND_BROADCAST, 
  WM_FONTCHANGE, 0, 0 );

    
	return 0; 	
}

