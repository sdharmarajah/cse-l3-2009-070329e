const cid = "@qsfox/qsfox;1";
var obj = Components.classes[cid].createInstance();
obj = obj.QueryInterface(Components.interfaces.Iqsfox); 
obj.isadmin();
if (obj.isadmin()) { print("Admin: YES"); } else { print("Admin: NO"); }
