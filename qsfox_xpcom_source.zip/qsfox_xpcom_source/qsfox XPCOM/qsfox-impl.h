#ifndef __QSFOX_IMPL_H__
#define __QSFOX_IMPL_H__

#include "qsfox.h"
# include "nsStringAPI.h"

#define QSFOX_CONTRACTID "@qsfox/qsfox;1"
#define QSFOX_CLASSNAME "qsfox"
#define QSFOX_CID { 0x6837c391, 0x27ab, 0x4ce1, { 0x8e, 0x22, 0xf7, 0x5a, 0x39, 0x63, 0x13, 0xe2 } }

class Cqsfox : public Iqsfox
{
public:
	NS_DECL_ISUPPORTS
	NS_DECL_IQSFOX

	Cqsfox();

private:
	~Cqsfox();

protected:
	/* additional members */
};

#endif