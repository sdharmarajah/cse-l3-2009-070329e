/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM isadmin.idl
 */

#ifndef __gen_isadmin_h__
#define __gen_isadmin_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    IIsAdmin */
#define IISADMIN_IID_STR "8a162fa3-3372-436b-a0e4-517c8389c057"

#define IISADMIN_IID \
  {0x8a162fa3, 0x3372, 0x436b, \
    { 0xa0, 0xe4, 0x51, 0x7c, 0x83, 0x89, 0xc0, 0x57 }}

class NS_NO_VTABLE IIsAdmin : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IISADMIN_IID)

  /* boolean isadmin (); */
  NS_IMETHOD Isadmin(PRBool *_retval) = 0;

  /* void addfont (in string path); */
  NS_IMETHOD Addfont(const char *path) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IISADMIN \
  NS_IMETHOD Isadmin(PRBool *_retval); \
  NS_IMETHOD Addfont(const char *path); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IISADMIN(_to) \
  NS_IMETHOD Isadmin(PRBool *_retval) { return _to Isadmin(_retval); } \
  NS_IMETHOD Addfont(const char *path) { return _to Addfont(path); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IISADMIN(_to) \
  NS_IMETHOD Isadmin(PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Isadmin(_retval); } \
  NS_IMETHOD Addfont(const char *path) { return !_to ? NS_ERROR_NULL_POINTER : _to->Addfont(path); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public IIsAdmin
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IISADMIN

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, IIsAdmin)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* boolean isadmin (); */
NS_IMETHODIMP _MYCLASS_::Isadmin(PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addfont (in string path); */
NS_IMETHODIMP _MYCLASS_::Addfont(const char *path)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_isadmin_h__ */
