/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM qsfox.idl
 */

#ifndef __gen_qsfox_h__
#define __gen_qsfox_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    Iqsfox */
#define IQSFOX_IID_STR "d6e2a643-4eeb-4a87-b675-75d748694b9f"

#define IQSFOX_IID \
  {0xd6e2a643, 0x4eeb, 0x4a87, \
    { 0xb6, 0x75, 0x75, 0xd7, 0x48, 0x69, 0x4b, 0x9f }}

class NS_NO_VTABLE Iqsfox : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IQSFOX_IID)

  /* boolean isadmin (); */
  NS_IMETHOD Isadmin(PRBool *_retval) = 0;

  /* void addfont (in string path); */
  NS_IMETHOD Addfont(const char *path) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IQSFOX \
  NS_IMETHOD Isadmin(PRBool *_retval); \
  NS_IMETHOD Addfont(const char *path); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IQSFOX(_to) \
  NS_IMETHOD Isadmin(PRBool *_retval) { return _to Isadmin(_retval); } \
  NS_IMETHOD Addfont(const char *path) { return _to Addfont(path); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IQSFOX(_to) \
  NS_IMETHOD Isadmin(PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Isadmin(_retval); } \
  NS_IMETHOD Addfont(const char *path) { return !_to ? NS_ERROR_NULL_POINTER : _to->Addfont(path); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public Iqsfox
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IQSFOX

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, Iqsfox)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* boolean isadmin (); */
NS_IMETHODIMP _MYCLASS_::Isadmin(PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addfont (in string path); */
NS_IMETHODIMP _MYCLASS_::Addfont(const char *path)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_qsfox_h__ */
