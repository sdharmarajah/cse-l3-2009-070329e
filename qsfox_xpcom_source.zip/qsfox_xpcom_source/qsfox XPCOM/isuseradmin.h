#include <windows.h>

BOOL IsUserAdmin(VOID);
