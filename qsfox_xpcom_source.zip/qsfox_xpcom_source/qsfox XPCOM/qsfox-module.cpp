/*
/*

Author Information

@author Isuru Udana Loku Narangoda
Department of Computer Science & Engineering,
University of Moratuwa,
Sri Lanka.

Blog: http://mytecheye.blogspot.com/
Facebook : http://www.facebook.com/isudana
GoogleTalk : isudana
Skype: isudana
Twitter: http://twitter.com/isudana
*/





#include "nsIGenericFactory.h"
#include "qsfox-impl.h"

NS_GENERIC_FACTORY_CONSTRUCTOR(Cqsfox)

static nsModuleComponentInfo components[] =
{
    {
       QSFOX_CLASSNAME, 
       QSFOX_CID,
       QSFOX_CONTRACTID,
       CqsfoxConstructor,
    }
};

NS_IMPL_NSGETMODULE("qsfoxModule", components) 

